import os
import openai
import config
openai.api_key=config.OPENAI_API_KEY

def generate_image(description):
 response1 = openai.Image.create(
  prompt=f"{description}",
  n=1,
  size="512x512"
)
 image_url=response1['data'][0]['url']
 return image_url

def generate_post(brand_description):
    prompt = f"Write a linkedin post about the brand: {brand_description}"
    response = openai.Completion.create(
        # engine="davinci",
        model="text-davinci-003",
        prompt=prompt,
        temperature=0.3,
        max_tokens=100,
        top_p=1.0,
        frequency_penalty=0.7,
        presence_penalty=1
    )    
    return response.choices[0].text.strip()



if __name__ == "__main__":
    brand_description = input("Enter the description of your brand: ")
    image_description=input("enter brand name")
    post = generate_post(brand_description)
    image=generate_image(image_description)
    print("\nGenerated Post:")
    print(post)
    print(image)
