import os
import requests
import shutil
import urllib
from PIL import Image,ImageFont,ImageDraw
import openai
import config
openai.api_key=config.OPENAI_API_KEY

def generate_image(description):
 response1 = openai.Image.create(
  prompt=f"{description}",
  n=1,
  size="512x512"
)
 image_url=response1['data'][0]['url']
 return image_url

def generate_post(day,brand_description,prevpost):
    # if day==1:       
    prompt = f"We are writing a progressive series of posts for linkedin.All posts should be different.Today,Write {day} linkedin post about the brand: {brand_description}"
    # else:
    #    prompt = f"Write {day} linkedin post about the brand: {brand_description},Also note that do not post something like previous post-{prevpost}"
    response = openai.Completion.create(
        # engine="davinci",
        model="text-davinci-003",
        prompt=prompt,
        temperature=0.3,
        max_tokens=100,
        top_p=1.0,
        frequency_penalty=0.7,
        presence_penalty=1
    )    
    postmatter=response.choices[0].text.strip()
    # prev=postmatter
    return postmatter




if __name__ == "__main__":
    brand_description = input("Enter the description of your brand: ")
    image_description=input("enter brand name")
    day=input("enter day")
    prevpost="1"
    post = generate_post(day,brand_description,prevpost)   
    prevpost=post 
    imagee=generate_image(image_description)
    response=requests.get(imagee)
    if response.status_code:
       fp=open('img.png',"wb")
       fp.write(response.content)
       fp.close()     
    my_image=Image.open("img.png")
    text=image_description
    Edited_image=ImageDraw.Draw(my_image)
    x,y,w,h=256,256, 200, 70 #rectangle coordinates,height,width
    outline_color = (0, 0, 0)  # Green color for the rectangle (RGB format)
    thickness = 2  # Line thickness of the rectangle
    Edited_image.rectangle([x, y, x + w, y + h], outline=outline_color, width=thickness)
    text_color = (0, 0, 255)  # Red color for the text (RGB format)
    font_size = 20
    font = ImageFont.truetype("arial.ttf", font_size)
    font = ImageFont.truetype("arial.ttf", font_size)    
    Edited_image.text((127,258), text, fill=text_color, font=font) 
    finalimg=my_image.save("finalimg.png")
    print("\nGenerated Post:")
    print(post)
    print(imagee)
    print(finalimg)
