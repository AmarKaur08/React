import requests
import os
from linkedin_api import linkedin
access_token="AQUr6KGyN7nbWlTY54zNkNshs0yEYbS3-gdiJNYM6DFz1IE4JRcwmE9Bs5PxTNBVwRYW42RSp1hAsDBR2uuGcv_JOlP2AkmcMD25egNuB7cs4iAl5Z1xSacvoNgAskDRumuGjJ8VtAQ44FFXf3mxXFcb3n0LPlirNLnInOPpoHh8dmt9-rrBIfG2kvTROi3zEL-1gXTMrnlprTrHsF7ck1rQPt9BYbUbGaCEFw8Z4eLYYFLeDvfT4PV5n9JqCh1OIDJxJJH9bn73bJT1AmRv-HNwgSv517xeGcMk5tgbTrOLRziNphUZ_jfPW1CAVBVZjSGHy_J7haT82Q93PGRabSv9GY_Bew"

# import requests

api_url = 'https://api.linkedin.com/v2/me'

headers = {
    'Authorization': f'Bearer {access_token}',
    'Connection': 'Keep-Alive',
    'Content-Type': 'application/json',
}

response = requests.get(api_url, headers=headers)
if response.status_code == 200:
    print('Access token is valid!')
else:
    print('Access token is invalid or has expired.')
# ///////////////////////////////////////////
# import requests

api_url = 'https://api.linkedin.com/v2/ugcPosts'

headers = {
    'Authorization': f'Bearer {access_token}',
    'Connection': 'Keep-Alive',
    'Content-Type': 'application/json',
}

post_body = {
    'author': 'urn:li:person:<your_linkedin_id>',
    'lifecycleState': 'PUBLISHED',
    'specificContent': {
        'com.linkedin.ugc.ShareContent': {
            'shareCommentary': {
                'text': 'Check out our latest blog post!',
            },
            'shareMediaCategory': 'ARTICLE',
            'media': [
                {
                    'status': 'READY',
                    'description': {
                        'text': 'Read our latest blog post about LinkedIn API!',
                    },
                    'originalUrl': '<your_blog_post_url>',
                },
            ],
        },
    },
    'visibility': {
        'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC',
    },
}

response = requests.post(api_url, headers=headers, json=post_body)
if response.status_code == 201:
    print('Post successfully created!')
else:
    print(f'Post creation failed with status code {response.status_code}: {response.text}')
