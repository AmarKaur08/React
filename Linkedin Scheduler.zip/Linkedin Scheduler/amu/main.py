import os
import openai
openai.api_key="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"
print('lets create a post ')
topic=input('what is the topic : ')
day=input('enter num of days : ')
target_aud=input( "tell target audience")

prompt = f"create a post for marketing on linkedin on {topic} and generate it according to {day} and do  marketing  according to that day  and generate it accordingly for {target_aud}"

model = "text-davinci-003"
response = openai.Completion.create(engine=model, prompt=prompt, max_tokens=100)

getdata = response.choices[0].text
print(getdata)
