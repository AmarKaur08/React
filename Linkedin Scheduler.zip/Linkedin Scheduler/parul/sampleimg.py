import os
import requests
import shutil
import urllib
from PIL import Image,ImageFont,ImageDraw
import openai
import config
# openai.api_key=config.OPENAI_API_KEYfrom PIL import Image, ImageDraw, ImageFont

if __name__ == "__main__":
    my_image=Image.open("img.png")
    text="Hello World"
    Edited_image=ImageDraw.Draw(my_image)
    x,y,w,h=125,256,200,50 #rectangle coordinates,height,width
    outline_color = (0, 0, 0)  # Green color for the rectangle (RGB format)
    thickness = 2  # Line thickness of the rectangle
    Edited_image.rectangle([x, y, x + w, y + h], outline=outline_color, width=thickness)
    text_color = (0, 0, 255)  # Red color for the text (RGB format)
    font_size = 20
    font = ImageFont.truetype("arial.ttf", font_size)
    # font_mono="Pillow/Tests/fonts/FreeMono.ttf"
    # font_color_green = (0,255,0,255)
    # font = ImageFont.truetype(font_mono, 28)
    # text_width, text_height = Edited_image.textsize(text, font=font)
    # text_x = x + (w - text_width) // 2
    # text_y = y + (h - text_height) // 2
    Edited_image.text((127,258), text, fill=text_color, font=font) 
    finalimg=my_image.save("finalimg.png")
    print("\nGenerated Post:")
    # print(post)
    # print(imagee)
    print(finalimg)